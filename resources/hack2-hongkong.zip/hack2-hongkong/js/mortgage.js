//mortgage.js
var initOffers = new
function() {
    Number.prototype.formatMoney = function(dp, ts, ds, cs) {
        var n = this,
        decPlaces = isNaN(dp = Math.abs(dp)) ? 2: dp,
        decSeparator = ds == undefined ? ".": ds,
        thouSeparator = ts == undefined ? ",": ts,
        currencySymbol = cs == undefined ? "$": cs,
        sign = n < 0 ? "-": "",
        i = parseInt(n = Math.abs( + n || 0).toFixed(decPlaces),10) + "",
        j = (j = i.length) > 3 ? j % 3: 0;
        return sign + currencySymbol + (j ? i.substr(0, j) + thouSeparator: "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thouSeparator) + (decPlaces ? decSeparator + Math.abs(n - i).toFixed(decPlaces).slice(2) : "");
    };

    // MORTGAGE CALCULATORS BASED ON ORIGINAL CODE (NOW HEAVILY MODIFIED) FROM: http://sharkysoft.com/misc/mortgage/
    var chartState = 0;
    var pieChartObj,
    areaChartObj;

    this.update_results = function(state) {
        if (!validate_input()){
          return;
        }
        if(state !== undefined){
          chartState = state;
        }
        var principal = $("form[name=mortgageInput] input[name=principal]").attr("value");
        var term = $("form[name=mortgageInput] select[name=term]").attr("value");
        var interest = $("form[name=mortgageInput] input[name=interest]").attr("value");
        var mortgage = new Mortgage(principal, interest, term);
        this.mortgage = mortgage;

        if (chartState === 0) {
            pieChartObj = pieChart(mortgage.pieChartData);
            areaChartObj = areaChart(mortgage);
            cmlWriteTotals(mortgage);
            chartState = 1;
        } else {
            pieChartObj.series[0].setData(mortgage.pieChartData);
            areaChartObj.series[0].setData(mortgage.interestSeries);
            areaChartObj.series[1].setData(mortgage.principalSeries);
            $('#stats_text').empty();
            cmlWriteTotals(mortgage);
        }
    };


    function Mortgage(principal, annual_interest_rate, years_to_pay) {
        principal = Math.round(principal);
        var monthly_interest_rate = annual_interest_rate / (12 * 100);
        var months_to_pay = Math.round(years_to_pay * 12);
        var monthly_payment = Math.ceil(principal * monthly_interest_rate / (1 - Math.pow(1 + monthly_interest_rate, -months_to_pay)));

        var schedule = [];
        var month = 1;
        // simple series arrays for charting
        var interestSeries = [];
        var principalSeries = [];
        // The full-series accumulator variables
        var total_interest = 0;
        var principal_remaining = principal;
        // The annual accumulators, which reset at end of each year
        var thisYearInterestPaid = 0;
        var thisYearPrincipalPaid = 0;
        // Next four are yearly data for yearly charts, structured as arrays so each can be a highcharts data series.
        // They begin with year 0 information.
        var yearEndInterestPaid = [0];
        var yearEndPrincipalPaid = [0];
        var yearEndTotalInterestPaid = [0];
        var yearEndPrincipalRemaining = [principal];


        while (principal_remaining > 0)
        {
            schedule[month] = new MortgagePayment(monthly_payment, monthly_interest_rate, month, principal_remaining);
            // Not sure why these two aren't in the constructor. Also, not sure they get used for anything.
            schedule[month].accumInterest = total_interest;
            schedule[month].principalAfterPay = principal_remaining;

            interestSeries.push(schedule[month].monthInterest);
            principalSeries.push(schedule[month].monthPrincipal);

            // These two are the full-series accumulators
            total_interest += schedule[month].monthInterest;
            principal_remaining -= schedule[month].monthPrincipal;

            // These are the annual accumulators
            thisYearInterestPaid += schedule[month].monthInterest;
            thisYearPrincipalPaid += schedule[month].monthPrincipal;
            // at the end of the year, push the year totals onto scheduleYearly
            if (month % 12 === 0) {
                yearEndInterestPaid.push(thisYearInterestPaid);
                yearEndPrincipalPaid.push(thisYearPrincipalPaid);
                yearEndTotalInterestPaid.push(total_interest);
                yearEndPrincipalRemaining.push(principal_remaining);
                // and reset the annual variables
                thisYearInterestPaid = 0;
                thisYearPrincipalPaid = 0;
            }
            ++month;
        }
        var total_payment = principal + total_interest;


        // Public Variables in the Mortgage Object
        this.amount = principal;
        this.rate = annual_interest_rate;
        this.term = years_to_pay;
        this.monthly_payment = monthly_payment;
        this.total_interest = total_interest;
        this.total_payment = total_payment;
        this.schedule = schedule;
        this.pieChartData = [
        ['Interest', total_interest],
        ['Principal', principal]
        ];
        this.yearlyData = {
            yearEndInterestPaid: yearEndInterestPaid,
            yearEndPrincipalPaid: yearEndPrincipalPaid,
            yearEndTotalInterestPaid: yearEndTotalInterestPaid,
            yearEndPrincipalRemaining: yearEndPrincipalRemaining
        };
        this.interestSeries = interestSeries;
        this.principalSeries = principalSeries;
    }

    function MortgagePayment(monthly_payment, monthly_interest_rate, month, principal_remaining) {
        var monthInterest = Math.round(principal_remaining * monthly_interest_rate);
        var monthPrincipal = monthly_payment - monthInterest;
        if (monthPrincipal > principal_remaining){
          monthPrincipal = principal_remaining;
        }
        var amount = monthInterest + monthPrincipal;
        var remainingAfter = principal_remaining - monthPrincipal;
        var accumInterest;

        this.month = month;
        this.amount = amount;
        this.monthPrincipal = monthPrincipal;
        this.monthInterest = monthInterest;
        this.remainingAfter = remainingAfter;
        this.accumInterest = accumInterest;
    }

    function formatVND(number) {
        if (number > 1000000) {
            return (number / 1000000).formatMoney(2, ",", '.', '') + "M VND";
        } else if (number > 1000) {
            return (number / 1000).formatMoney(2, ",", '.', '') + "K VND";
        } else {
            return (number).formatMoney(0, ",", '.', '') + "K VND";
        }
    }

    function cmlWriteSchedule(scheduleObject) {
        $('#schedule').empty();
        for (var i = 1; i < scheduleObject.length; i += 1) {
            text = "Month " + scheduleObject[i].month + ": payment=" + (scheduleObject[i].amount).formatMoney();
            $('#schedule').append("<p>" + text + "</p>");
        }
    }
    function cmlWriteTotals(mortgageObject) {
        var material = "<p>Pay Monthly: " + formatVND(mortgageObject.monthly_payment) + "<br>Total Interest: " + formatVND(mortgageObject.total_interest) + "<br />All Payments: " + formatVND(mortgageObject.total_payment);
        $('#stats_text').append(material);
    }
    function validate_input() {
        var principal = $("form[name=mortgageInput] input[name=principal]").attr("value");
        var term = $("form[name=mortgageInput] select[name=term]").attr("value");
        var interest = $("form[name=mortgageInput] input[name=interest]").attr("value");

        principal = parseInt(principal,10);
        if (isNaN(principal) || principal <= 0)
        {
            alert("You must enter a positive number for the loan amount.");
            input.principal.focus();
            return false;
        }

        term = parseInt(term,10);
        if (isNaN(term) || term <= 0 || term >= 100)
        {
            alert("You must enter a number between 1 and 99 for the repayment term.");
            input.term.focus();
            return false;
        }

        interest = parseFloat(interest);
        if (isNaN(interest) || interest <= 0)
        {
            alert("You must enter a positive number for the interest rate.");
            input.interest.focus();
            return false;
        }
        return true;
    }

    function pieChart(incomingData) {
        var pieChartObj = new Highcharts.Chart({
            chart: {
                renderTo: 'chart1_container',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                backgroundColor: "transparent"
            },
            colors: [
            '#18A94B',
            '#076739'
            ],
            credits: {
                enabled: false
            },
            title: {
                text: null
                //"% Principal vs. <br> % Interest"
            },
            tooltip: {
                formatter: function() {
                    return '<b>' + this.point.name + '</b>: ' + Math.round(this.percentage * Math.pow(10, 2)) / Math.pow(10, 2) + ' %';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function() {
                            return '<b>' + this.point.name + '</b>: ' + Math.round(this.percentage * Math.pow(10, 2)) / Math.pow(10, 2) + ' %';
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Payment Totals',
                data: incomingData
            }]
        });
        return pieChartObj;
    }

    function areaChart(incomingData) {
        var mortgageObject = incomingData;
        var areaChartObj = new Highcharts.Chart({
            chart: {
                renderTo: 'chart2_container',
                type: 'area',
                backgroundColor: "transparent"
            },
            colors: [
            '#CFA778',
            '#0CA474'
            ],
            credits: {
                enabled: false
            },
            title: {
                text: 'Monthly Principal vs. Interest'
            },
            xAxis: {
                labels: {
                    formatter: function() {
                        return this.value;
                        // clean, unformatted number for year
                    }
                }
            },
            yAxis: {
                title: {
                    text: 'VND'
                },
                labels: {
                    formatter: function() {
                        return this.value / 1000000 + 'M';
                    }
                }
            },
            tooltip: {
                formatter: function() {
                    var s = '<b>Month #' + this.x + ':</b>';

                    $.each(this.points,
                    function(i, point) {
                        s += '<br/><span style="color:' + point.series.color + '">' + point.series.name + '</span> paid: ' + Highcharts.numberFormat(point.y, 0) + ' VND';
                    });

                    return s;

                },
                /*formatter: function() {
	                return '<span style="color:' + series.color + '>' + series.name + '</span>: paid in month ' + point.x + ': <b>' + Highcharts.numberFormat(this.y, 0) + '</b>VND'
	            },*/
                crosshairs: true,
                shared: true
            },
            /*plotOptions: {
	            area: {
	                //pointStart: 1940,
	                marker: {
	                    enabled: false,
	                    symbol: 'circle',
	                    radius: 2,
	                    states: {
	                        hover: {
	                            enabled: true
	                        }
	                    }
	                }
	            }
	        },*/
            series: [{
                name: 'Interest',
                data: mortgageObject.interestSeries
            },
            {
                name: 'Principal',
                data: mortgageObject.principalSeries
            }]
        });
        return areaChartObj;
    }
};