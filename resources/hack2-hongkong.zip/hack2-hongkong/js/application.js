function initView(publisher, app) {
    $(".view.active .sidenavToggle").on("click.sideNav",
    function(event) {
        var ca = $(".view.active .contentContainer");
        event.preventDefault();
        var w = $(".sideNav").width() - 68;
        if (ca.position().left < -40) {
            w = 0;
        }
        $(".view.active .sideNavItems").show();
        $(".view.active .sideNavItemsClosed").hide();
        ca.animate({
            left: -w
        },
        500,
        function() {
            if (ca.position().left < -30) {
                $(".view.active .sideNavItems").hide();
                $(".view.active .sideNavItemsClosed").show();
            }
        });
    });
    $(".view.active .menuHeader").unbind("click");
    $(".view.active .menuHeader").bind('click',
    function(event) {
        event.preventDefault();
        $(".view.active .menuContent").hide();
        var section = $(this).attr("data-section");
        $(".view.active .menuContent[data-rel=" + section + "]").show();
    });

    if (app.request.params.controller === 'dashboard') {
        $(".view.active [data-section=schedule]").trigger('click');
    } else {
        var ca = $(".view.active .contentContainer");
        if ((ca.length > 0) && ca.position().left > -30) {
            $(".view.active .sidenavToggle").trigger('click');
        } else {
            $(".view.active .sideNavItems").hide();
            $(".view.active .sideNavItemsClosed").show();
        }
    }
}
function initCustomerView(app){
  $("div[data-controller='offers'] div[data-action=customer_view]").attr("data-index", 0);
  $("div[data-controller='offers'] div[data-action=customer_view]").unbind("click");
  $("div[data-controller='offers'] div[data-action=customer_view]").bind('click',
  function(event) {
      event.preventDefault();
      var index = parseInt($(this).attr("data-index"), 10);
      if (index == 3) {
          app.get('offers', 'agent_view');
      } else {
          index++;
      }
      $(this).attr("data-index", index);
  });
}
function initFeedback(app) {
    $("div[data-controller='feedback'] div[data-action=index]").attr("data-index", 0);
    $("div[data-controller='feedback'] div[data-action=index]").unbind("click");
    $("div[data-controller='feedback'] div[data-action=index]").bind('click',
    function(event) {
        event.preventDefault();
        var index = parseInt($(this).attr("data-index"), 10);
        if (index == 1) {
            app.get('appointments', 'show');
        } else {
            index++;
        }
        $(this).attr("data-index", index);
    });
}

$(document).ready(function() {
    var sp = $.spineless({
        controllers: {
            offers: {
                agent_view: function(elements, request) {
                    this.render(elements);
                    initOffers.update_results(0);
                },
                customer_view: function(elements, request) {
                    this.render(elements);
                    initOffers.update_results(0);
                    initCustomerView(this);
                }
            },
            feedback: {
                index: function(elements, request) {
                    this.render(elements);
                    initFeedback(this);
                }
            }
        }
    });
    sp.subscribe("afterRender", initView);
    sp.get('dashboard', 'index');
});

